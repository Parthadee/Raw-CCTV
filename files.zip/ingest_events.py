"""
ingest_events.py — Push processed events from .jsonl files into the API

Usage:
    python pipeline/ingest_events.py --events-dir data/events/
    python pipeline/ingest_events.py --file data/events/STORE_BLR_002_events.jsonl
"""

import json
import time
import argparse
import requests
from pathlib import Path

API_BASE    = "http://localhost:8000"
BATCH_SIZE  = 500          # API max per call
SLEEP_MS    = 50           # throttle between batches (ms)


def ingest_file(filepath: str, dry_run: bool = False) -> dict:
    path   = Path(filepath)
    events = []

    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError as e:
                    print(f"  [WARN] Skipping malformed line: {e}")

    print(f"\nIngesting {path.name}: {len(events)} events")

    if dry_run:
        print("  [DRY RUN] Skipping actual POST")
        return {"total": len(events), "batches": 0}

    total_ok      = 0
    total_errors  = 0
    batch_count   = 0

    for i in range(0, len(events), BATCH_SIZE):
        batch = events[i : i + BATCH_SIZE]
        try:
            resp = requests.post(
                f"{API_BASE}/events/ingest",
                json={"events": batch},
                timeout=30,
            )
            if resp.status_code == 200:
                data = resp.json()
                ok  = data.get("ingested", len(batch))
                err = data.get("errors",   0)
                total_ok     += ok
                total_errors += err
                batch_count  += 1
                print(f"  Batch {batch_count}: {ok} ok, {err} errors")
            else:
                print(f"  [ERROR] HTTP {resp.status_code}: {resp.text[:200]}")
                total_errors += len(batch)
        except requests.ConnectionError:
            print(f"  [ERROR] Cannot connect to {API_BASE}. Is the API running?")
            print("  Run: docker compose up -d")
            return {"total": len(events), "ok": 0, "errors": len(events)}

        time.sleep(SLEEP_MS / 1000)

    print(f"  ✓ Done: {total_ok} ingested, {total_errors} errors")
    return {"total": len(events), "ok": total_ok, "errors": total_errors}


def main():
    parser = argparse.ArgumentParser(description="Ingest events into Store Intelligence API")
    parser.add_argument("--events-dir", help="Directory containing .jsonl event files")
    parser.add_argument("--file",       help="Single .jsonl file to ingest")
    parser.add_argument("--dry-run",    action="store_true", help="Parse only, don't POST")
    args = parser.parse_args()

    if args.file:
        ingest_file(args.file, dry_run=args.dry_run)
    elif args.events_dir:
        files = sorted(Path(args.events_dir).glob("*.jsonl"))
        if not files:
            print(f"No .jsonl files found in {args.events_dir}")
            return
        for f in files:
            ingest_file(str(f), dry_run=args.dry_run)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
