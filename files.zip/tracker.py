"""
tracker.py — Re-ID, session management, zone logic, staff detection

Core responsibilities:
  1. Map ByteTrack track_ids → stable visitor_ids (Re-ID)
  2. Detect direction of crossing (ENTRY vs EXIT)
  3. Classify staff vs customers
  4. Track zone dwell time
  5. Detect re-entry (same person after EXIT)
  6. Handle group entry (emit N events, not 1)
  7. Correlate with POS for BILLING_QUEUE_ABANDON
"""

import uuid
import time
import math
from collections import defaultdict
from datetime import datetime, timezone


# ── Constants ─────────────────────────────────────────────────────────────────

# Entry zone: fraction of frame height that defines the entry/exit threshold
# Anything above this line = outside; below = inside
ENTRY_LINE_Y_RATIO  = 0.35   # Top 35% of frame = entry threshold band

# Staff detection heuristics (colour-based proxy; adjust for actual footage)
# We use bounding-box aspect ratio + position as a lightweight proxy.
# For best results, swap in a VLM call or a fine-tuned classifier.
STAFF_ASPECT_RATIO_MIN = 2.5   # Staff often appear full-body (tall bbox)
STAFF_ZONE_FREQUENCY   = 8     # Seen in 8+ different zones → likely staff

# Re-ID: if a track disappears then reappears, how many seconds before
# we consider it a new visitor vs the same person returning
REID_TIMEOUT_SECONDS = 30      # Short gap → same session; long gap → re-entry

# Dwell tracking
DWELL_EMIT_INTERVAL_MS = 30_000   # Emit ZONE_DWELL every 30 seconds

# Billing queue: minimum people in billing zone to trigger queue logic
BILLING_QUEUE_THRESHOLD = 2

# POS correlation window: visitor must be in billing zone within this many
# seconds before a transaction to count as converted
POS_CORRELATION_WINDOW_SEC = 300   # 5 minutes


class VisitorSession:
    """Represents one visit by one person from ENTRY to EXIT."""

    def __init__(self, visitor_id: str, track_id: int, timestamp: str):
        self.visitor_id    = visitor_id
        self.track_id      = track_id          # current ByteTrack ID
        self.entry_time    = timestamp
        self.exit_time     = None
        self.is_staff      = False
        self.current_zone  = None
        self.zone_history  = []                # list of (zone, enter_ts, exit_ts)
        self.zone_enter_ts = None
        self.last_dwell_emit_ts = None
        self.session_seq   = 0                 # increments with each event
        self.last_seen_ts  = timestamp
        self.bbox_history  = []                # for Re-ID trajectory matching
        self.is_closed     = False
        self.in_billing    = False
        self.billing_entry_ts = None
        self.converted     = False             # matched to a POS transaction

    def next_seq(self) -> int:
        self.session_seq += 1
        return self.session_seq

    def age_seconds(self, now_ts: str) -> float:
        """Seconds since last seen."""
        fmt = "%Y-%m-%dT%H:%M:%SZ"
        try:
            t0 = datetime.strptime(self.last_seen_ts, fmt).replace(tzinfo=timezone.utc)
            t1 = datetime.strptime(now_ts, fmt).replace(tzinfo=timezone.utc)
            return (t1 - t0).total_seconds()
        except Exception:
            return 0.0


class VisitorTracker:
    """
    Manages all active visitor sessions and emits behavioural events.

    Flow:
      update(detections) → list[event_dict]

    Called once per processed frame. Returns zero or more events that
    the caller (detect.py) passes to EventEmitter.
    """

    def __init__(self, store_layout: dict, camera_role: str, camera_id: str):
        self.store_layout      = store_layout
        self.camera_role       = camera_role   # "entry", "floor", "billing"
        self.camera_id         = camera_id

        # track_id (ByteTrack) → visitor_id mapping
        self.track_to_visitor: dict[int, str] = {}

        # visitor_id → VisitorSession
        self.sessions: dict[str, VisitorSession] = {}

        # visitor_id → list of closed sessions (for re-entry detection)
        self.closed_sessions: dict[str, list[VisitorSession]] = defaultdict(list)

        # Re-ID: bounding box trajectory fingerprints for closed sessions
        # key = simple trajectory hash, value = visitor_id
        self.trajectory_index: dict[str, str] = {}

        # POS transactions loaded externally
        self.pos_transactions: list[dict] = []

        # Zone definitions from layout
        self.zones = self._parse_zones()

        # Frame dimensions (set on first frame)
        self.frame_w = None
        self.frame_h = None

    # ── Setup ────────────────────────────────────────────────────────────────

    def set_pos_transactions(self, txns: list):
        self.pos_transactions = txns

    def _parse_zones(self) -> list[dict]:
        """Extract zone definitions relevant to this camera from layout."""
        zones = []
        cameras = self.store_layout.get("cameras", [])
        for cam in cameras:
            if self.camera_role in cam.get("camera_id", "").lower():
                for zone in cam.get("zones", []):
                    zones.append(zone)
        # Fallback: use all zones
        if not zones:
            for cam in cameras:
                zones.extend(cam.get("zones", []))
        return zones

    def _get_zone_for_bbox(self, bbox: tuple) -> str | None:
        """
        Determine which zone a bounding box centroid falls in.
        
        Zone coordinates in layout are normalised 0.0–1.0 relative to frame.
        Returns zone_id string or None.
        """
        if not self.frame_w or not self.frame_h:
            return None

        x1, y1, x2, y2 = bbox
        cx = ((x1 + x2) / 2) / self.frame_w   # normalised centroid
        cy = ((y1 + y2) / 2) / self.frame_h

        for zone in self.zones:
            bounds = zone.get("bounds", {})
            if not bounds:
                continue
            zx1 = bounds.get("x1", 0)
            zy1 = bounds.get("y1", 0)
            zx2 = bounds.get("x2", 1)
            zy2 = bounds.get("y2", 1)
            if zx1 <= cx <= zx2 and zy1 <= cy <= zy2:
                return zone.get("zone_id") or zone.get("name")
        return None

    def _is_entry_crossing(self, bbox: tuple, prev_bbox: tuple | None) -> str | None:
        """
        Determine if a bounding box crossing the entry threshold.
        
        Returns "ENTRY", "EXIT", or None.
        
        Strategy: Entry camera watches the doorway.
        - Person moving downward (increasing Y) past threshold → ENTRY
        - Person moving upward (decreasing Y) past threshold → EXIT
        """
        if self.camera_role != "entry" or not self.frame_h:
            return None

        threshold_y = int(self.frame_h * ENTRY_LINE_Y_RATIO)
        x1, y1, x2, y2 = bbox
        cy_now = (y1 + y2) / 2

        if prev_bbox is None:
            return None

        px1, py1, px2, py2 = prev_bbox
        cy_prev = (py1 + py2) / 2

        crossed = (cy_prev < threshold_y <= cy_now) or \
                  (cy_now  < threshold_y <= cy_prev)

        if not crossed:
            return None

        if cy_now > cy_prev:
            return "ENTRY"   # moving into store (downward in camera frame)
        else:
            return "EXIT"    # moving out of store

    # ── Staff Detection ───────────────────────────────────────────────────────

    def _classify_staff(self, session: VisitorSession) -> bool:
        """
        Heuristic staff classification.
        
        Production approach: fine-tuned classifier or VLM prompt.
        Here we use two lightweight proxies:
          1. Bounding box aspect ratio (staff often appear full-length)
          2. Zone frequency (staff traverse many zones regularly)
        
        These work on clean footage; a VLM would be more robust.
        """
        if len(session.bbox_history) < 5:
            return False  # not enough data yet

        # Proxy 1: average bounding box aspect ratio
        ratios = []
        for bbox in session.bbox_history[-10:]:
            x1, y1, x2, y2 = bbox
            w = max(x2 - x1, 1)
            h = max(y2 - y1, 1)
            ratios.append(h / w)
        avg_ratio = sum(ratios) / len(ratios)

        # Proxy 2: unique zone count
        unique_zones = len({z[0] for z in session.zone_history})

        is_staff = (avg_ratio > STAFF_ASPECT_RATIO_MIN and unique_zones >= 3) or \
                   (unique_zones >= STAFF_ZONE_FREQUENCY)

        return is_staff

    # ── Re-ID ─────────────────────────────────────────────────────────────────

    def _trajectory_fingerprint(self, bbox_history: list) -> str:
        """
        Simple trajectory fingerprint for Re-ID.
        
        Takes last N bboxes, computes movement direction buckets.
        Coarse enough to survive minor variations; fine enough to
        distinguish different people.
        
        Production alternative: OSNet / torchreid appearance embeddings.
        """
        if len(bbox_history) < 3:
            return ""

        sample = bbox_history[-6:]
        directions = []
        for i in range(1, len(sample)):
            prev = sample[i-1]
            curr = sample[i]
            dx = ((curr[0]+curr[2])/2) - ((prev[0]+prev[2])/2)
            dy = ((curr[1]+curr[3])/2) - ((prev[1]+prev[3])/2)
            # Bucket into 8 directions
            angle = round(math.atan2(dy, dx) / (math.pi / 4)) * 45
            directions.append(str(int(angle)))
        return ",".join(directions)

    def _find_reentry_match(self, track_id: int, bbox: tuple, timestamp: str) -> str | None:
        """
        Check if this new track is a known visitor returning.
        
        Returns visitor_id if matched, else None.
        """
        fingerprint = self._trajectory_fingerprint([bbox])

        for vid, closed_list in self.closed_sessions.items():
            for sess in closed_list:
                age = sess.age_seconds(timestamp)
                if REID_TIMEOUT_SECONDS < age < 3600:  # 30s–60min window
                    # Simple spatial proximity check
                    if sess.bbox_history:
                        last_bbox = sess.bbox_history[-1]
                        lx = (last_bbox[0] + last_bbox[2]) / 2
                        ly = (last_bbox[1] + last_bbox[3]) / 2
                        cx = (bbox[0] + bbox[2]) / 2
                        cy = (bbox[1] + bbox[3]) / 2
                        dist = math.hypot(cx - lx, cy - ly)
                        # Same person re-entering: typically near the entry zone
                        if dist < 150 and self.camera_role == "entry":
                            return vid
        return None

    # ── Billing Queue ─────────────────────────────────────────────────────────

    def _billing_queue_depth(self) -> int:
        """Count visitors currently in billing zone."""
        count = 0
        for sess in self.sessions.values():
            if not sess.is_staff and sess.current_zone and \
               "billing" in (sess.current_zone or "").lower():
                count += 1
        return count

    def _check_pos_conversion(self, visitor_id: str, timestamp: str) -> bool:
        """
        Did this visitor (in billing zone) match a POS transaction?
        Time-window correlation: billing entry within 5 min of transaction.
        """
        sess = self.sessions.get(visitor_id)
        if not sess or not sess.billing_entry_ts:
            return False

        fmt = "%Y-%m-%dT%H:%M:%SZ"
        try:
            billing_dt = datetime.strptime(sess.billing_entry_ts, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            return False

        for txn in self.pos_transactions:
            try:
                txn_dt = datetime.strptime(
                    txn["timestamp"].replace("+00:00", "Z"), fmt
                ).replace(tzinfo=timezone.utc)
                delta = (txn_dt - billing_dt).total_seconds()
                if 0 <= delta <= POS_CORRELATION_WINDOW_SEC:
                    return True
            except (ValueError, KeyError):
                continue
        return False

    # ── Public helpers ────────────────────────────────────────────────────────

    def get_visitor_id(self, track_id: int) -> str | None:
        return self.track_to_visitor.get(track_id)

    def is_staff(self, visitor_id: str) -> bool:
        sess = self.sessions.get(visitor_id)
        return sess.is_staff if sess else False

    # ── Main update ───────────────────────────────────────────────────────────

    def update(
        self,
        detections: list[dict],
        frame,
        timestamp: str,
        frame_idx: int,
        fps: float,
    ) -> list[dict]:
        """
        Process one frame's detections → list of events.

        Called per frame from detect.py.
        """
        import numpy as np

        if self.frame_h is None and frame is not None:
            self.frame_h, self.frame_w = frame.shape[:2]

        events = []
        active_track_ids = set()

        for det in detections:
            track_id   = det["track_id"]
            bbox       = det["bbox"]
            confidence = det["confidence"]

            if track_id is None:
                continue  # untracked detection — skip

            active_track_ids.add(track_id)

            # ── Map track_id → visitor_id ──────────────────────────────────
            if track_id not in self.track_to_visitor:
                # New track: check for re-entry match first
                reentry_vid = self._find_reentry_match(track_id, bbox, timestamp)

                if reentry_vid:
                    # Known visitor returning
                    self.track_to_visitor[track_id] = reentry_vid
                    # Restore session
                    if reentry_vid in self.sessions:
                        sess = self.sessions[reentry_vid]
                        sess.track_id   = track_id
                        sess.is_closed  = False
                        sess.last_seen_ts = timestamp
                    events.append(self._make_event(
                        reentry_vid, "REENTRY", timestamp, bbox, confidence,
                        zone_id=None, dwell_ms=0,
                    ))
                else:
                    # Brand new visitor
                    visitor_id = f"VIS_{uuid.uuid4().hex[:6]}"
                    self.track_to_visitor[track_id] = visitor_id
                    sess = VisitorSession(visitor_id, track_id, timestamp)
                    self.sessions[visitor_id] = sess

                    # Only emit ENTRY from entry camera
                    if self.camera_role == "entry":
                        events.append(self._make_event(
                            visitor_id, "ENTRY", timestamp, bbox, confidence,
                            zone_id=None, dwell_ms=0,
                        ))

            visitor_id = self.track_to_visitor[track_id]
            sess = self.sessions.get(visitor_id)
            if sess is None:
                continue

            sess.last_seen_ts = timestamp
            sess.bbox_history.append(bbox)
            if len(sess.bbox_history) > 30:
                sess.bbox_history.pop(0)

            # Periodic staff re-classification (gets better as track matures)
            if frame_idx % 30 == 0:
                sess.is_staff = self._classify_staff(sess)

            # ── Entry / Exit crossing detection ───────────────────────────
            prev_bbox = sess.bbox_history[-2] if len(sess.bbox_history) >= 2 else None
            crossing = self._is_entry_crossing(bbox, prev_bbox)
            if crossing == "EXIT" and not sess.is_closed:
                sess.is_closed = True
                sess.exit_time = timestamp

                # Check for billing abandon
                if sess.in_billing and not sess.converted:
                    events.append(self._make_event(
                        visitor_id, "BILLING_QUEUE_ABANDON", timestamp, bbox, confidence,
                        zone_id=sess.current_zone, dwell_ms=0,
                    ))

                events.append(self._make_event(
                    visitor_id, "EXIT", timestamp, bbox, confidence,
                    zone_id=None, dwell_ms=0,
                ))
                # Archive session for re-entry detection
                self.closed_sessions[visitor_id].append(sess)

            # ── Zone tracking (floor + billing cameras) ───────────────────
            if self.camera_role in ("floor", "billing"):
                current_zone = self._get_zone_for_bbox(bbox)

                if current_zone != sess.current_zone:
                    # Zone change
                    if sess.current_zone is not None:
                        # Compute dwell for previous zone
                        dwell_ms = self._compute_dwell_ms(
                            sess.zone_enter_ts, timestamp
                        )
                        sess.zone_history.append(
                            (sess.current_zone, sess.zone_enter_ts, timestamp)
                        )
                        events.append(self._make_event(
                            visitor_id, "ZONE_EXIT", timestamp, bbox, confidence,
                            zone_id=sess.current_zone, dwell_ms=dwell_ms,
                        ))

                        # Billing zone exit
                        if "billing" in (sess.current_zone or "").lower():
                            converted = self._check_pos_conversion(visitor_id, timestamp)
                            if not converted and sess.in_billing:
                                events.append(self._make_event(
                                    visitor_id, "BILLING_QUEUE_ABANDON", timestamp, bbox,
                                    confidence, zone_id=sess.current_zone, dwell_ms=dwell_ms,
                                ))
                            sess.in_billing = False

                    if current_zone is not None:
                        events.append(self._make_event(
                            visitor_id, "ZONE_ENTER", timestamp, bbox, confidence,
                            zone_id=current_zone, dwell_ms=0,
                        ))

                        # Billing zone entry
                        if "billing" in (current_zone or "").lower():
                            queue_depth = self._billing_queue_depth()
                            if queue_depth >= BILLING_QUEUE_THRESHOLD:
                                events.append(self._make_event(
                                    visitor_id, "BILLING_QUEUE_JOIN", timestamp, bbox,
                                    confidence, zone_id=current_zone, dwell_ms=0,
                                    extra={"queue_depth": queue_depth},
                                ))
                            sess.in_billing      = True
                            sess.billing_entry_ts = timestamp

                    sess.current_zone  = current_zone
                    sess.zone_enter_ts = timestamp
                    sess.last_dwell_emit_ts = timestamp

                # Periodic ZONE_DWELL events
                elif current_zone is not None:
                    dwell_so_far = self._compute_dwell_ms(sess.zone_enter_ts, timestamp)
                    last_emit_dwell = self._compute_dwell_ms(
                        sess.last_dwell_emit_ts, timestamp
                    )
                    if last_emit_dwell >= DWELL_EMIT_INTERVAL_MS:
                        events.append(self._make_event(
                            visitor_id, "ZONE_DWELL", timestamp, bbox, confidence,
                            zone_id=current_zone, dwell_ms=dwell_so_far,
                        ))
                        sess.last_dwell_emit_ts = timestamp

        # ── Handle disappeared tracks ─────────────────────────────────────
        disappeared = set(self.track_to_visitor.keys()) - active_track_ids
        for tid in disappeared:
            vid = self.track_to_visitor.get(tid)
            if not vid:
                continue
            sess = self.sessions.get(vid)
            if sess and not sess.is_closed:
                age = sess.age_seconds(timestamp)
                if age > REID_TIMEOUT_SECONDS:
                    # Likely left frame permanently — close session
                    sess.is_closed = True
                    sess.exit_time = timestamp
                    if self.camera_role == "entry":
                        events.append(self._make_event(
                            vid, "EXIT", timestamp,
                            sess.bbox_history[-1] if sess.bbox_history else (0,0,0,0),
                            0.5, zone_id=None, dwell_ms=0,
                        ))
                    self.closed_sessions[vid].append(sess)
                    del self.track_to_visitor[tid]

        return events

    def close_all_sessions(self, timestamp: str) -> list[dict]:
        """Called at end of clip to flush all open sessions."""
        events = []
        for vid, sess in list(self.sessions.items()):
            if not sess.is_closed:
                sess.is_closed = True
                if self.camera_role == "entry":
                    events.append(self._make_event(
                        vid, "EXIT", timestamp,
                        sess.bbox_history[-1] if sess.bbox_history else (0,0,0,0),
                        0.5, zone_id=None, dwell_ms=0,
                    ))
        return events

    # ── Event builder ─────────────────────────────────────────────────────────

    def _make_event(
        self,
        visitor_id:  str,
        event_type:  str,
        timestamp:   str,
        bbox:        tuple,
        confidence:  float,
        zone_id:     str | None,
        dwell_ms:    int,
        extra:       dict = None,
    ) -> dict:
        sess = self.sessions.get(visitor_id)
        seq  = sess.next_seq() if sess else 1

        # Determine SKU zone label from layout
        sku_zone = None
        if zone_id:
            for zone in self.zones:
                if zone.get("zone_id") == zone_id or zone.get("name") == zone_id:
                    sku_zone = zone.get("sku_zone") or zone.get("zone_id")
                    break

        queue_depth = (extra or {}).get("queue_depth")

        return {
            "event_id":   str(uuid.uuid4()),
            "store_id":   None,          # filled by EventEmitter
            "camera_id":  self.camera_id,
            "visitor_id": visitor_id,
            "event_type": event_type,
            "timestamp":  timestamp,
            "zone_id":    zone_id,
            "dwell_ms":   dwell_ms,
            "is_staff":   sess.is_staff if sess else False,
            "confidence": round(confidence, 3),
            "metadata": {
                "queue_depth": queue_depth,
                "sku_zone":    sku_zone,
                "session_seq": seq,
            },
            "_bbox":       bbox,          # internal; stripped by emitter
        }

    @staticmethod
    def _compute_dwell_ms(start_ts: str | None, end_ts: str) -> int:
        if not start_ts:
            return 0
        fmt = "%Y-%m-%dT%H:%M:%SZ"
        try:
            t0 = datetime.strptime(start_ts, fmt).replace(tzinfo=timezone.utc)
            t1 = datetime.strptime(end_ts,   fmt).replace(tzinfo=timezone.utc)
            return max(0, int((t1 - t0).total_seconds() * 1000))
        except ValueError:
            return 0
