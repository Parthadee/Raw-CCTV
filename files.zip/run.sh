#!/bin/bash
# run.sh — Process all CCTV clips for all stores
# Usage: bash pipeline/run.sh
#
# Expects:
#   data/clips/<store_id>/<camera_angle>.mp4
#   data/store_layout.json
#   data/pos_transactions.csv
#
# Output:
#   data/events/<store_id>_events.jsonl

set -e

LAYOUT="data/store_layout.json"
POS="data/pos_transactions.csv"
CLIPS_DIR="data/clips"
EVENTS_DIR="data/events"

mkdir -p "$EVENTS_DIR"

echo "╔══════════════════════════════════════════╗"
echo "║  Store Intelligence — Detection Pipeline  ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# Loop over each store subfolder
for store_dir in "$CLIPS_DIR"/*/; do
    store_id=$(basename "$store_dir")
    output="$EVENTS_DIR/${store_id}_events.jsonl"

    # Remove old output so we start fresh
    rm -f "$output"

    echo "▶ Processing store: $store_id"

    for clip in "$store_dir"*.mp4; do
        [ -f "$clip" ] || continue
        echo "  → Clip: $clip"
        python pipeline/detect.py \
            --video   "$clip" \
            --store   "$store_id" \
            --layout  "$LAYOUT" \
            --output  "$output" \
            --pos     "$POS"
    done

    echo "  ✓ Events written to $output"
    echo ""
done

echo "══════════════════════════════════════════"
echo "All clips processed."
echo "Next step: ingest events into the API:"
echo ""
echo "  docker compose up -d"
echo "  python pipeline/ingest_events.py --events-dir data/events/"
echo "══════════════════════════════════════════"
