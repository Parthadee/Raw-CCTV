"""
detect.py — Main detection + tracking script for Store Intelligence Pipeline
Uses YOLOv8 for person detection and ByteTrack for multi-object tracking.

Why YOLOv8?
- Best balance of speed vs accuracy for retail CCTV (15fps, 1080p)
- Native ByteTrack integration via ultralytics
- Strong community support + pretrained weights
- Handles partial occlusion better than older YOLO versions
"""

import cv2
import json
import argparse
from pathlib import Path
from datetime import datetime, timezone, timedelta

from ultralytics import YOLO

from tracker import VisitorTracker
from emit import EventEmitter


# ── Configuration ────────────────────────────────────────────────────────────

PERSON_CLASS_ID = 0          # COCO class 0 = person
MIN_CONFIDENCE  = 0.35       # Don't drop low-conf; flag them instead
FRAME_SKIP      = 2          # Process every Nth frame (speed vs accuracy)
YOLO_MODEL      = "yolov8m.pt"  # Medium model: good accuracy, runs on CPU


# ── Camera metadata ──────────────────────────────────────────────────────────

# Maps camera filename patterns → camera_id and camera role
# Adjust these to match your actual clip filenames
CAMERA_CONFIG = {
    "entry":   {"camera_id": "CAM_ENTRY_01",   "role": "entry"},
    "floor":   {"camera_id": "CAM_FLOOR_01",   "role": "floor"},
    "billing": {"camera_id": "CAM_BILLING_01", "role": "billing"},
}


def resolve_camera_config(video_path: str) -> dict:
    """Infer camera_id and role from filename."""
    name = Path(video_path).stem.lower()
    for keyword, config in CAMERA_CONFIG.items():
        if keyword in name:
            return config
    return {"camera_id": "CAM_UNKNOWN_01", "role": "unknown"}


def parse_clip_start_time(video_path: str) -> datetime:
    """
    Extract the clip's real-world start time.
    
    Looks for ISO timestamp in filename like: store_blr_entry_2026-03-03T14-00-00.mp4
    Falls back to a hardcoded base time if not found.
    """
    stem = Path(video_path).stem
    parts = stem.replace("_", "-").split("-")
    # Try to find YYYY-MM-DD pattern
    for i in range(len(parts) - 2):
        try:
            year = int(parts[i])
            if 2020 <= year <= 2030:
                date_str = f"{parts[i]}-{parts[i+1]}-{parts[i+2]}"
                dt = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
                return dt
        except (ValueError, IndexError):
            continue

    # Fallback: use challenge reference date
    print(f"[WARN] Could not parse clip start time from '{stem}', using fallback.")
    return datetime(2026, 3, 3, 14, 0, 0, tzinfo=timezone.utc)


def frame_to_timestamp(clip_start: datetime, frame_idx: int, fps: float) -> str:
    """Convert a frame index to an ISO-8601 UTC timestamp string."""
    offset_seconds = frame_idx / fps
    ts = clip_start + timedelta(seconds=offset_seconds)
    return ts.strftime("%Y-%m-%dT%H:%M:%SZ")


# ── Core Detection Loop ───────────────────────────────────────────────────────

def process_clip(
    video_path: str,
    store_id: str,
    layout_path: str,
    output_path: str,
    pos_path: str = None,
    visualise: bool = False,
):
    """
    Process a single CCTV clip end-to-end:
      1. Run YOLOv8 person detection on each frame
      2. Feed detections into ByteTrack (via VisitorTracker)
      3. Emit structured events via EventEmitter
      4. Write events to .jsonl output file
    """
    print(f"\n{'='*60}")
    print(f"Processing : {video_path}")
    print(f"Store      : {store_id}")
    print(f"Output     : {output_path}")
    print(f"{'='*60}\n")

    # Load layout
    with open(layout_path) as f:
        store_layout = json.load(f)

    camera_cfg  = resolve_camera_config(video_path)
    clip_start  = parse_clip_start_time(video_path)
    camera_id   = camera_cfg["camera_id"]
    camera_role = camera_cfg["role"]

    # Load models
    model   = YOLO(YOLO_MODEL)
    tracker = VisitorTracker(store_layout, camera_role, camera_id)
    emitter = EventEmitter(store_id, camera_id, output_path)

    # Load POS transactions if available (for billing correlation)
    pos_transactions = []
    if pos_path and Path(pos_path).exists():
        import csv
        with open(pos_path) as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row["store_id"] == store_id:
                    pos_transactions.append(row)
        print(f"Loaded {len(pos_transactions)} POS transactions for {store_id}")

    tracker.set_pos_transactions(pos_transactions)

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {video_path}")

    fps         = cap.get(cv2.CAP_PROP_FPS) or 15.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    frame_idx   = 0
    event_count = 0

    print(f"Video : {fps:.1f} fps, {total_frames} frames (~{total_frames/fps/60:.1f} min)\n")

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        frame_idx += 1

        # Skip frames for speed (still accurate at 15fps → process every 2nd)
        if frame_idx % FRAME_SKIP != 0:
            continue

        timestamp = frame_to_timestamp(clip_start, frame_idx, fps)

        # ── YOLOv8 Detection ──────────────────────────────────────────────
        # track=True uses ByteTrack internally — assigns track IDs per person
        results = model.track(
            frame,
            persist=True,       # maintain track IDs across frames
            classes=[PERSON_CLASS_ID],
            conf=MIN_CONFIDENCE,
            verbose=False,
        )

        detections = []
        if results and results[0].boxes is not None:
            boxes = results[0].boxes
            for box in boxes:
                track_id   = int(box.id[0]) if box.id is not None else None
                confidence = float(box.conf[0])
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                bbox = (int(x1), int(y1), int(x2), int(y2))

                detections.append({
                    "track_id":   track_id,
                    "bbox":       bbox,
                    "confidence": confidence,
                    "frame_idx":  frame_idx,
                    "timestamp":  timestamp,
                })

        # ── Tracker update → events ────────────────────────────────────────
        new_events = tracker.update(detections, frame, timestamp, frame_idx, fps)

        for event in new_events:
            emitter.emit(event)
            event_count += 1

        # ── Optional visualisation ─────────────────────────────────────────
        if visualise:
            _draw_debug(frame, detections, tracker)
            cv2.imshow("Detection", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

        # Progress every 500 frames
        if frame_idx % 500 == 0:
            pct = frame_idx / total_frames * 100
            print(f"  Frame {frame_idx}/{total_frames} ({pct:.0f}%) — events: {event_count}")

    cap.release()
    if visualise:
        cv2.destroyAllWindows()

    # Flush any open sessions as EXIT events
    close_events = tracker.close_all_sessions(timestamp)
    for event in close_events:
        emitter.emit(event)
        event_count += 1

    emitter.flush()

    print(f"\n✓ Done. Total events emitted: {event_count}")
    print(f"  Output: {output_path}\n")
    return event_count


def _draw_debug(frame, detections, tracker):
    """Draw bounding boxes + track IDs for visualisation mode."""
    for det in detections:
        x1, y1, x2, y2 = det["bbox"]
        tid   = det["track_id"]
        conf  = det["confidence"]
        color = (0, 255, 0)

        # Red if staff
        visitor_id = tracker.get_visitor_id(tid)
        if visitor_id and tracker.is_staff(visitor_id):
            color = (0, 0, 255)

        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        label = f"ID:{tid} {conf:.2f}"
        cv2.putText(frame, label, (x1, y1 - 8),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)


# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Store Intelligence — Detection Pipeline"
    )
    parser.add_argument("--video",    required=True,  help="Path to CCTV clip (.mp4)")
    parser.add_argument("--store",    required=True,  help="Store ID e.g. STORE_BLR_002")
    parser.add_argument("--layout",   required=True,  help="Path to store_layout.json")
    parser.add_argument("--output",   required=True,  help="Output .jsonl path for events")
    parser.add_argument("--pos",      default=None,   help="Path to pos_transactions.csv")
    parser.add_argument("--visualise",action="store_true", help="Show detection window")
    args = parser.parse_args()

    process_clip(
        video_path   = args.video,
        store_id     = args.store,
        layout_path  = args.layout,
        output_path  = args.output,
        pos_path     = args.pos,
        visualise    = args.visualise,
    )


if __name__ == "__main__":
    main()
