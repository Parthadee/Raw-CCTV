"""
emit.py — Event schema validation and JSONL emission

Responsibilities:
  - Inject store_id into every event
  - Strip internal fields (prefixed with _)
  - Validate required fields
  - Write to .jsonl output file
  - Buffer writes for performance
"""

import json
import uuid
from pathlib import Path
from datetime import datetime


REQUIRED_FIELDS = [
    "event_id", "store_id", "camera_id", "visitor_id",
    "event_type", "timestamp", "is_staff", "confidence",
]

VALID_EVENT_TYPES = {
    "ENTRY", "EXIT", "ZONE_ENTER", "ZONE_EXIT",
    "ZONE_DWELL", "BILLING_QUEUE_JOIN", "BILLING_QUEUE_ABANDON", "REENTRY",
}


class EventEmitter:
    """
    Validates and writes structured events to a .jsonl file.

    Usage:
        emitter = EventEmitter(store_id="STORE_BLR_002",
                               camera_id="CAM_ENTRY_01",
                               output_path="data/events/store_blr_002.jsonl")
        emitter.emit(event_dict)
        emitter.flush()
    """

    def __init__(self, store_id: str, camera_id: str, output_path: str):
        self.store_id    = store_id
        self.camera_id   = camera_id
        self.output_path = Path(output_path)
        self.output_path.parent.mkdir(parents=True, exist_ok=True)

        self._buffer:      list[dict] = []
        self._buffer_size: int = 100           # flush every N events
        self._total_emitted: int = 0
        self._validation_errors: int = 0

        # Open file in append mode so multiple clips can add to same file
        self._fh = open(self.output_path, "a", encoding="utf-8")
        print(f"[EventEmitter] Writing to {self.output_path}")

    def emit(self, event: dict) -> bool:
        """
        Validate and queue one event for writing.
        Returns True if valid, False if validation failed.
        (Low-confidence events are still emitted — just flagged.)
        """
        # Inject store context
        event["store_id"]  = self.store_id
        event["camera_id"] = self.camera_id

        # Strip internal fields (prefixed _)
        clean = {k: v for k, v in event.items() if not k.startswith("_")}

        # Validate
        valid, error = self._validate(clean)
        if not valid:
            self._validation_errors += 1
            print(f"[WARN] Invalid event skipped: {error} | event_type={event.get('event_type')}")
            return False

        self._buffer.append(clean)
        self._total_emitted += 1

        if len(self._buffer) >= self._buffer_size:
            self._write_buffer()

        return True

    def flush(self):
        """Write remaining buffered events and close file."""
        self._write_buffer()
        self._fh.close()
        print(
            f"[EventEmitter] Flushed. "
            f"Total emitted: {self._total_emitted} | "
            f"Validation errors: {self._validation_errors}"
        )

    def _write_buffer(self):
        for ev in self._buffer:
            self._fh.write(json.dumps(ev) + "\n")
        self._fh.flush()
        self._buffer.clear()

    def _validate(self, event: dict) -> tuple[bool, str | None]:
        # Required fields present
        for field in REQUIRED_FIELDS:
            if field not in event or event[field] is None:
                return False, f"Missing required field: {field}"

        # event_id must be a valid UUID
        try:
            uuid.UUID(event["event_id"])
        except (ValueError, AttributeError):
            return False, f"Invalid event_id: {event['event_id']}"

        # event_type must be in catalogue
        if event["event_type"] not in VALID_EVENT_TYPES:
            return False, f"Unknown event_type: {event['event_type']}"

        # timestamp must be ISO-8601
        try:
            datetime.strptime(event["timestamp"], "%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            return False, f"Invalid timestamp: {event['timestamp']}"

        # confidence in [0, 1]
        conf = event.get("confidence", -1)
        if not (0.0 <= conf <= 1.0):
            return False, f"Confidence out of range: {conf}"

        # is_staff must be boolean
        if not isinstance(event.get("is_staff"), bool):
            return False, "is_staff must be boolean"

        # metadata must exist
        if "metadata" not in event or not isinstance(event["metadata"], dict):
            return False, "metadata must be a dict"

        return True, None
